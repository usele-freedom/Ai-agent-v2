# Video Review AI Agent - Vercel Deployment

This is a complete, working Video Review AI Agent that can be deployed to Vercel.

## 🚀 Quick Deploy to Vercel

### Option 1: Deploy via Vercel Dashboard (Easiest)

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click "Add New" → "Project"
3. Upload these files:
   - `index.html`
   - `vercel.json`
   - `package.json`
   - `api/analyze.js`
4. Click "Deploy"
5. Done! Your app will be live at `https://your-project.vercel.app`

### Option 2: Deploy via Vercel CLI

1. Install Vercel CLI:
   ```bash
   npm install -g vercel
   ```

2. Navigate to this folder and run:
   ```bash
   vercel
   ```

3. Follow the prompts to deploy

## 📁 Project Structure

```
video-review-vercel/
├── index.html          # Main HTML file (frontend)
├── api/
│   └── analyze.js      # Serverless function (backend proxy)
├── vercel.json         # Vercel configuration
├── package.json        # Node.js configuration
└── README.md           # This file
```

## ✨ How It Works

1. **Frontend (index.html)**: User uploads video, frames are extracted
2. **Backend (api/analyze.js)**: Serverless function proxies requests to Anthropic API
3. **This solves CORS issues**: Browser → Your Vercel API → Anthropic API

## 🔑 Using the App

1. Get your Anthropic API key from [console.anthropic.com](https://console.anthropic.com/)
2. Enter your API key in the app
3. Upload a video
4. Get AI-powered feedback!

## 💡 Why This Version Works

The previous version failed because browsers can't call the Anthropic API directly due to CORS restrictions. This version uses a serverless function as a backend proxy, which solves the problem.

## 🔒 Security

Your API key is:
- Stored only in your browser's local storage
- Never exposed in the frontend code
- Only sent to your own Vercel backend, which forwards it to Anthropic

## 💰 Cost

- Vercel: Free tier includes everything you need
- Anthropic API: Pay per use (~few cents per video analysis)
